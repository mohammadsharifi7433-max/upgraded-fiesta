If the existing Flask app does not already expose health checks, add:

@app.get("/api/health")
def health():
    return {"ok": True}

For production, extend it to verify database and Redis connectivity separately.
