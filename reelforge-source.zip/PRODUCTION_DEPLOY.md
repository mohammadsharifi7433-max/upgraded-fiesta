# ReelForge AI v7 — Production Deployment

## Local production-like run
1. Copy `.env.example` to `.env`.
2. Set a strong `SECRET_KEY`.
3. Add `OPENAI_API_KEY` if AI features are enabled.
4. Change the PostgreSQL password in `docker-compose.yml`.
5. Run:
   docker compose up --build

App: http://localhost:8000

## Architecture
Browser -> Flask/Gunicorn -> PostgreSQL
                       -> Redis/RQ worker -> FFmpeg
                       -> AI provider
                       -> object storage (next integration)

## Before public launch
- Put the app behind HTTPS/reverse proxy.
- Move uploads/outputs to object storage.
- Use signed URLs for private files.
- Add real authentication/session management and CSRF protection.
- Run database migrations instead of raw schema application.
- Enforce atomic credit-ledger transactions.
- Verify payment webhooks with provider-specific signatures.
- Add rate limiting and per-user upload quotas.
- Add automatic deletion of uploaded media.
- Add monitoring, error tracking and backups.
- Never commit `.env` or API keys.
