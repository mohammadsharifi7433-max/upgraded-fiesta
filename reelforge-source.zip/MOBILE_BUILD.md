# ReelForge AI v8 — Mobile

## What is included
- Mobile-first UI shell
- PWA manifest
- Service worker
- 192/512 app icons
- Capacitor configuration for Android/iOS
- Shared backend architecture inherited from v7

## PWA test
Serve the project over HTTPS (or localhost), then open it in Chrome/Android and choose "Install app".

## Android build
Requires Node.js + Android Studio + Android SDK.
1. npm install
2. npx cap add android
3. npx cap sync
4. npx cap open android
5. Build an APK from Android Studio.

## iOS build
Requires macOS + Xcode + Apple Developer account.
1. npm install
2. npx cap add ios
3. npx cap sync
4. npx cap open ios
5. Archive/sign in Xcode.

## Important
This environment does not include a configured Android SDK/Gradle toolchain, so a signed production APK cannot be honestly claimed as built here. The project is prepared for the Android/iOS build step.
