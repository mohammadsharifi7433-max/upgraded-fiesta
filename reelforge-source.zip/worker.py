import os
from redis import Redis
from rq import Worker, Queue

redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
conn = Redis.from_url(redis_url)
queues = [Queue("video", connection=conn)]
if __name__ == "__main__":
    Worker(queues, connection=conn).work()
