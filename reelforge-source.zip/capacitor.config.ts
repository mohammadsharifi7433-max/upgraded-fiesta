import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ai.reelforge.app',
  appName: 'ReelForge AI',
  webDir: 'mobile',
  bundledWebRuntime: false
};

export default config;
