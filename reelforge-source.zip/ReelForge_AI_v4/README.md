# ReelForge AI v4 — SaaS MVP

This version adds the first SaaS layer on top of v3:
- SQLite users + secure password hashing
- Login / registration / logout
- Per-user credits
- Dashboard and processing history
- Free / Creator / Pro plan definitions
- Provider-independent payment adapter with manual and generic hosted-checkout modes
- Signed payment webhook that upgrades plan/credits only after verified `paid` events
- One-click video processing from the authenticated dashboard
- Existing AI transcription, highlight selection, subtitles, captions and hashtags

## Run
1. Install FFmpeg and ensure `ffmpeg` + `ffprobe` are on PATH.
2. `python -m venv .venv`
3. Activate it.
4. `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and set `OPENAI_API_KEY`.
6. `python app.py`
7. Open `http://127.0.0.1:5000`.

## Payment architecture
The app does not hard-code Stripe. Payment is behind a small provider adapter (`PaymentProvider`). The included `manual` mode is safe for development, while `generic` mode can point to a lawful hosted checkout provider using `PAYMENT_CHECKOUT_BASE_URL`. A production adapter should implement the same interface and send signed webhooks to `/api/payments/webhook`.

Webhook requests must include `X-ReelForge-Signature`, which is an HMAC-SHA256 hex digest of the raw request body using `PAYMENT_WEBHOOK_SECRET`. A `paid` event atomically changes the payment to paid and credits the user's account.

## Important payment note
The payment layer is deliberately provider-neutral. Stripe currently lists Iran as a prohibited high-risk jurisdiction and its global availability list does not include Iran. Do not create a false-country Stripe account or attempt to bypass its verification. For real billing, connect a payment provider that legally supports the actual business entity/jurisdiction.

## Production gaps before charging customers
- PostgreSQL instead of SQLite
- Redis + background worker for long video jobs
- Object storage (S3-compatible)
- CSRF protection and stricter auth/session controls
- Email verification + password reset
- Rate limits, malware scanning, quotas and automatic file deletion
- Real payment provider adapter + provider-specific webhook verification/reconciliation
- Admin panel for plan/credit management
- Monitoring and error tracking
- Terms, privacy policy and data-retention policy
- Deployment behind HTTPS
