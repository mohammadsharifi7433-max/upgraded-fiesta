import os, sqlite3, uuid, subprocess, shutil, re, json, secrets, hmac, hashlib, time
from pathlib import Path
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, render_template, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import requests

load_dotenv()
BASE=Path(__file__).resolve().parent
DB=BASE/'reelforge.db'; UPLOADS=BASE/'uploads'; OUTPUTS=BASE/'outputs'
UPLOADS.mkdir(exist_ok=True); OUTPUTS.mkdir(exist_ok=True)
app=Flask(__name__); app.secret_key=os.getenv('FLASK_SECRET_KEY', secrets.token_hex(32))
app.config['MAX_CONTENT_LENGTH']=int(os.getenv('MAX_UPLOAD_MB','250'))*1024*1024
OPENAI_KEY=os.getenv('OPENAI_API_KEY','').strip(); TRANSCRIBE_MODEL=os.getenv('OPENAI_TRANSCRIBE_MODEL','gpt-4o-mini-transcribe'); TEXT_MODEL=os.getenv('OPENAI_TEXT_MODEL','gpt-6-luna'); CLIP_COUNT=5
PLANS={'free':{'name':'Free','price':0,'credits':3},'creator':{'name':'Creator','price':9,'credits':30},'pro':{'name':'Pro','price':29,'credits':120}}
PAYMENT_PROVIDER=os.getenv('PAYMENT_PROVIDER','manual').strip().lower()
PAYMENT_WEBHOOK_SECRET=os.getenv('PAYMENT_WEBHOOK_SECRET','').strip()

class PaymentProvider:
    name='base'
    def create_checkout(self, payment_id, user, plan):
        raise NotImplementedError

class ManualProvider(PaymentProvider):
    name='manual'
    def create_checkout(self, payment_id, user, plan):
        return {'provider':self.name,'status':'pending','payment_id':payment_id,'checkout_url':None,'message':'Payment provider is not configured yet.'}

class GenericHostedProvider(PaymentProvider):
    """Provider-neutral adapter. A real provider adapter can implement the same interface.
    Set PAYMENT_PROVIDER=generic only when your provider expects your own checkout URL/webhook flow.
    """
    name='generic'
    def create_checkout(self, payment_id, user, plan):
        base=os.getenv('PAYMENT_CHECKOUT_BASE_URL','').strip().rstrip('/')
        url=f'{base}?payment_id={payment_id}' if base else None
        return {'provider':self.name,'status':'pending','payment_id':payment_id,'checkout_url':url,'message':'Hosted checkout adapter placeholder.'}

PROVIDERS={'manual':ManualProvider(),'generic':GenericHostedProvider()}

ALLOWED={'.mp4','.mov','.m4v','.webm','.avi','.mkv'}

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db(); c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,plan TEXT NOT NULL DEFAULT 'free',credits INTEGER NOT NULL DEFAULT 3,created_at TEXT DEFAULT CURRENT_TIMESTAMP); CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,status TEXT NOT NULL,filename TEXT,credits_used INTEGER DEFAULT 1,result_json TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id)); CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,plan TEXT NOT NULL,status TEXT NOT NULL,amount REAL NOT NULL,provider TEXT NOT NULL DEFAULT 'manual',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));'''); c.commit(); c.close()
init_db()

def current_user():
    uid=session.get('uid');
    if not uid:return None
    c=db(); u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone(); c.close(); return u

def login_required(fn):
    @wraps(fn)
    def w(*a,**kw):
        if not current_user(): return redirect(url_for('login',next=request.path))
        return fn(*a,**kw)
    return w

def run(cmd):
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if p.returncode!=0: raise RuntimeError(p.stderr[-3000:])
    return p.stdout

def duration(path): return float(run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)]).strip())

def transcribe(path):
    with open(path,'rb') as f:
        r=requests.post('https://api.openai.com/v1/audio/transcriptions',headers={'Authorization':f'Bearer {OPENAI_KEY}'},files={'file':(path.name,f,'application/octet-stream')},data={'model':TRANSCRIBE_MODEL,'response_format':'verbose_json','timestamp_granularities[]':'segment'},timeout=600)
    if not r.ok: raise RuntimeError(r.text[:1000])
    return r.json()

def ai_select(transcript,dur):
    seg=[{'start':round(float(s.get('start',0)),2),'end':round(float(s.get('end',0)),2),'text':s.get('text','').strip()} for s in transcript.get('segments',[]) if s.get('text')]
    prompt={'task':'Select the best 5 short-form moments.','requirements':{'count':5,'duration_seconds':'20-60'},'criteria':['strong hook','standalone idea','emotion/surprise/usefulness','payoff','avoid incomplete sentences'],'video_duration_seconds':dur,'segments':seg}
    r=requests.post('https://api.openai.com/v1/responses',headers={'Authorization':f'Bearer {OPENAI_KEY}','Content-Type':'application/json'},json={'model':TEXT_MODEL,'input':[{'role':'system','content':'You are an expert short-form editor. Return only JSON: {"clips":[{"start":0,"end":30,"reason":"..."}]}.'},{'role':'user','content':json.dumps(prompt,ensure_ascii=False)}]},timeout=180)
    if not r.ok: raise RuntimeError(r.text[:1200])
    t=r.json().get('output_text','').strip(); m=re.search(r'\{.*\}',t,re.S)
    if not m: raise RuntimeError('No JSON')
    return json.loads(m.group())

def fallback(dur):
    clip=max(20,min(45,dur/5 if dur else 30));
    if dur<=clip:return [{'start':0,'end':dur,'reason':'Full available video'}]
    return [{'start':round(max(0,(dur-clip)*i/4),2),'end':round(min(dur,max(0,(dur-clip)*i/4)+clip),2),'reason':'Fallback selection'} for i in range(5)]

def srt_time(sec):
    ms=int(round(sec*1000)); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000; return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'

def write_srt(segs,start,end,path):
    rows=[]; i=1
    for s in segs:
        a=max(start,float(s.get('start',0))); b=min(end,float(s.get('end',0)))
        if b>a and s.get('text'): rows.append(f'{i}\n{srt_time(a-start)} --> {srt_time(b-start)}\n{s["text"].strip()}\n'); i+=1
    path.write_text('\n'.join(rows),encoding='utf-8')

def make_clip(src,out,start,end,srt=None):
    vf='scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920'
    if srt: vf += ",subtitles='"+str(srt).replace('\\','/').replace(':','\\:')+"'"
    run(['ffmpeg','-y','-ss',str(start),'-i',str(src),'-t',str(max(.1,end-start)),'-vf',vf,'-c:v','libx264','-preset','veryfast','-crf','22','-c:a','aac','-b:a','128k','-movflags','+faststart',str(out)])

def metadata(text):
    if not OPENAI_KEY:return {'hook':'A strong moment worth watching','caption':'Turn this moment into a Reel.','hashtags':['#reels','#contentcreator','#shorts']}
    r=requests.post('https://api.openai.com/v1/responses',headers={'Authorization':f'Bearer {OPENAI_KEY}','Content-Type':'application/json'},json={'model':TEXT_MODEL,'input':[{'role':'system','content':'Return only JSON with hook, caption, hashtags array of 5.'},{'role':'user','content':text[:8000]}]},timeout=120)
    if not r.ok:return {'hook':'A strong moment worth watching','caption':'Turn this moment into a Reel.','hashtags':['#reels','#contentcreator','#shorts']}
    m=re.search(r'\{.*\}',r.json().get('output_text',''),re.S); return json.loads(m.group()) if m else {'hook':'A strong moment worth watching','caption':'Turn this moment into a Reel.','hashtags':['#reels','#contentcreator','#shorts']}

@app.context_processor
def ctx(): return {'user':current_user(),'plans':PLANS}
@app.get('/')
def home(): return render_template('index.html')
@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        email=request.form.get('email','').strip().lower(); pw=request.form.get('password','')
        if len(pw)<8: flash('Password must be at least 8 characters.','error')
        else:
            try:
                c=db(); c.execute('INSERT INTO users(email,password_hash) VALUES(?,?)',(email,generate_password_hash(pw))); c.commit(); uid=c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()['id']; c.close(); session['uid']=uid; return redirect(url_for('dashboard'))
            except sqlite3.IntegrityError: flash('Email already registered.','error')
    return render_template('auth.html',mode='register')
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        c=db(); u=c.execute('SELECT * FROM users WHERE email=?',(request.form.get('email','').strip().lower(),)).fetchone(); c.close()
        if u and check_password_hash(u['password_hash'],request.form.get('password','')): session['uid']=u['id']; return redirect(request.args.get('next') or url_for('dashboard'))
        flash('Invalid email or password.','error')
    return render_template('auth.html',mode='login')
@app.get('/logout')
def logout(): session.clear(); return redirect(url_for('home'))
@app.get('/dashboard')
@login_required
def dashboard():
    c=db(); jobs=c.execute('SELECT * FROM jobs WHERE user_id=? ORDER BY created_at DESC',(current_user()['id'],)).fetchall(); payments=c.execute('SELECT * FROM payments WHERE user_id=? ORDER BY created_at DESC',(current_user()['id'],)).fetchall(); c.close(); return render_template('dashboard.html',jobs=jobs,payments=payments)
@app.get('/pricing')
def pricing(): return render_template('pricing.html')
@app.post('/api/checkout')
@login_required
def checkout():
    plan=request.json.get('plan','') if request.is_json else ''
    if plan not in PLANS or plan=='free': return jsonify(error='Invalid paid plan'),400
    provider=PROVIDERS.get(PAYMENT_PROVIDER,PROVIDERS['manual'])
    pid=uuid.uuid4().hex[:16]
    c=db(); c.execute('INSERT INTO payments(id,user_id,plan,status,amount,provider) VALUES(?,?,?,?,?,?)',(pid,current_user()['id'],plan,'pending',PLANS[plan]['price'],provider.name)); c.commit(); c.close()
    result=provider.create_checkout(pid,current_user(),plan)
    return jsonify(payment_id=pid,**result)

@app.post('/api/payments/webhook')
def payment_webhook():
    raw=request.get_data()
    if not PAYMENT_WEBHOOK_SECRET:
        return jsonify(error='Webhook secret is not configured'),503
    supplied=request.headers.get('X-ReelForge-Signature','')
    expected=hmac.new(PAYMENT_WEBHOOK_SECRET.encode(),raw,hashlib.sha256).hexdigest()
    if not hmac.compare_digest(supplied,expected): return jsonify(error='Invalid signature'),401
    try:data=request.get_json(force=True)
    except Exception:return jsonify(error='Invalid JSON'),400
    pid=str(data.get('payment_id','')); status=str(data.get('status','')).lower()
    if status not in {'paid','failed','cancelled'} or not pid:return jsonify(error='Invalid webhook payload'),400
    c=db(); payment=c.execute('SELECT * FROM payments WHERE id=?',(pid,)).fetchone()
    if not payment:c.close(); return jsonify(error='Payment not found'),404
    if status=='paid' and payment['status']!='paid':
        plan=PLANS[payment['plan']]
        c.execute('UPDATE payments SET status=? WHERE id=?',('paid',pid))
        c.execute('UPDATE users SET plan=?, credits=credits+? WHERE id=?',(payment['plan'],plan['credits'],payment['user_id']))
    else:
        c.execute('UPDATE payments SET status=? WHERE id=?',(status,pid))
    c.commit(); c.close(); return jsonify(ok=True)
@app.post('/api/process')
@login_required
def process():
    u=current_user()
    if u['credits']<1:return jsonify(error='No credits left. Choose a plan to continue.'),402
    if 'video' not in request.files:return jsonify(error='No video uploaded'),400
    f=request.files['video']; ext=Path(f.filename or '').suffix.lower()
    if ext not in ALLOWED:return jsonify(error='Unsupported video format'),400
    job=uuid.uuid4().hex[:12]; src=UPLOADS/f'{job}{ext}'; f.save(src)
    c=db(); c.execute('UPDATE users SET credits=credits-1 WHERE id=? AND credits>0',(u['id'],)); c.execute('INSERT INTO jobs(id,user_id,status,filename,credits_used) VALUES(?,?,?,?,1)',(job,u['id'],'processing',f.filename)); c.commit(); c.close()
    try:
        dur=duration(src); transcript={'segments':[]}; ai_used=False
        if OPENAI_KEY:
            try: transcript=transcribe(src); ai_used=True
            except Exception as e: print('transcription:',e)
        seg=transcript.get('segments',[]); picks=[]
        if ai_used and seg:
            try:picks=ai_select(transcript,dur).get('clips',[])[:5]
            except Exception as e: print('selection:',e)
        if not picks:picks=fallback(dur)
        results=[]
        for i,p in enumerate(picks,1):
            st=max(0,float(p.get('start',0))); en=min(dur,float(p.get('end',st+30)))
            if en-st<8:continue
            out=OUTPUTS/f'{job}_clip_{i}.mp4'; srt=None
            if seg:srt=OUTPUTS/f'{job}_{i}.srt'; write_srt(seg,st,en,srt)
            make_clip(src,out,st,en,srt)
            excerpt=' '.join(x.get('text','') for x in seg if float(x.get('end',0))>st and float(x.get('start',0))<en)
            meta=metadata(excerpt)
            results.append({'url':f'/api/output/{out.name}','start':round(st,2),'end':round(en,2),'reason':p.get('reason','AI highlight'),'hook':meta['hook'],'caption':meta['caption'],'hashtags':meta.get('hashtags',[])})
        c=db(); c.execute('UPDATE jobs SET status=?,result_json=? WHERE id=?',('completed',json.dumps(results),job)); c.commit(); c.close()
        return jsonify(job_id=job,ai_used=ai_used,clips=results)
    except Exception as e:
        c=db(); c.execute('UPDATE users SET credits=credits+1 WHERE id=?',(u['id'],)); c.execute('UPDATE jobs SET status=? WHERE id=?',('failed',job)); c.commit(); c.close(); return jsonify(error=str(e)),500
    finally:
        try:src.unlink()
        except:pass
@app.get('/api/output/<path:name>')
@login_required
def output(name): return send_from_directory(OUTPUTS,name,as_attachment=False)
@app.get('/api/health')
def health():return jsonify(ok=True,ai_enabled=bool(OPENAI_KEY),ffmpeg=shutil.which('ffmpeg') is not None)

if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.getenv('PORT','5000')),debug=False)
