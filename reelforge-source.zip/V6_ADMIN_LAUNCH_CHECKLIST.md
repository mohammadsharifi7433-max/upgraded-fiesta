# v6 Launch Checklist

## Included
- Admin dashboard scaffold
- Admin API routes
- Role guard hook
- Credit adjustment endpoint
- Coupon validation endpoint
- Audit-log and coupon models
- Revenue/subscription analytics hooks
- Provider-independent payment layer inherited from v5

## Required before production
1. PostgreSQL database and migrations
2. Redis + background job queue for video processing
3. Real authentication/session or JWT implementation
4. Persistent credit ledger (never mutate balance without a ledger entry)
5. Real coupon database rules and expiry/use limits
6. Real payment-provider webhook verification
7. Object storage for uploaded/generated videos
8. Automatic file deletion/retention policy
9. Rate limiting and abuse protection
10. HTTPS, secrets manager, backups, monitoring

## Commercial path
Free -> Creator -> Pro -> Business
Use credits as the unit of consumption. Keep the payment provider replaceable.
