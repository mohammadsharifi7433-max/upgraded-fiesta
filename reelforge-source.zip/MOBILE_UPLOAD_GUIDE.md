# ReelForge AI — Upload from Android

The complete project is already extracted in this folder. Keep the folder structure intact.

Important: do not upload the ZIP as the application source. GitHub must receive the files/folders themselves.

If Chrome's Android file picker only shows Photos/Camera, use GitHub in Desktop site mode or use the GitHub connector in ChatGPT to connect the repository securely.
