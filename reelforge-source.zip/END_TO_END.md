# ReelForge AI v9 — End-to-End Mobile Client

The mobile PWA now calls the existing Flask backend:
- GET /api/health
- POST /api/process
- GET /api/output/<file>

The processing path is:
Upload -> transcription (when OPENAI_API_KEY exists) -> AI highlight selection -> 9:16 FFmpeg rendering -> metadata generation -> preview/download.

## Run
Use the backend app already included under `ReelForge_AI_v4/app.py`.
Install its requirements, set environment variables, make sure FFmpeg is installed, and serve the mobile UI from the same origin.

## Important
The current backend endpoint is synchronous. For public production traffic, move `/api/process` into the Redis/RQ worker and return a job ID immediately. That prevents long requests from timing out.

## Mobile installation
With HTTPS (or localhost during development), Android Chrome can install the PWA from the browser menu. Capacitor configuration remains included for later Play Store/App Store packaging.
