from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

@dataclass
class Coupon:
    code: str
    percent_off: Optional[int] = None
    amount_off: Optional[int] = None
    max_uses: Optional[int] = None
    uses: int = 0
    active: bool = True
    expires_at: Optional[datetime] = None

@dataclass
class AuditLog:
    admin_id: str
    action: str
    target_id: str
    metadata: dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
