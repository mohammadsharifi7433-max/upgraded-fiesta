from functools import wraps
from flask import Blueprint, jsonify, request

admin_api = Blueprint("admin_api", __name__, url_prefix="/api/admin")

def require_admin(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        # Replace with the real authenticated session/JWT check.
        # Production rule: only users with role == "admin" may pass.
        if request.headers.get("X-Admin-Role") != "admin":
            return jsonify({"error": "admin_required"}), 403
        return fn(*args, **kwargs)
    return wrapper

@admin_api.get("/health")
@require_admin
def health():
    return jsonify({"ok": True, "service": "admin"})

@admin_api.get("/overview")
@require_admin
def overview():
    # Data-layer integration point.
    return jsonify({
        "users": 0,
        "active_subscriptions": 0,
        "credits_used": 0,
        "revenue": 0,
        "orders": 0
    })

@admin_api.post("/credits/adjust")
@require_admin
def adjust_credits():
    payload = request.get_json(force=True) or {}
    user_id = payload.get("user_id")
    amount = payload.get("amount")
    reason = payload.get("reason", "")
    if not user_id or not isinstance(amount, int):
        return jsonify({"error": "user_id_and_integer_amount_required"}), 400
    return jsonify({"ok": True, "user_id": user_id, "amount": amount, "reason": reason})

@admin_api.post("/coupons/validate")
def validate_coupon():
    payload = request.get_json(force=True) or {}
    code = str(payload.get("code", "")).strip().upper()
    # Replace with DB lookup and expiry/use-limit validation.
    return jsonify({"valid": False, "code": code})
