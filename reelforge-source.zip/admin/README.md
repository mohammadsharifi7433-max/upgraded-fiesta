# ReelForge AI v6 — Admin & Growth Layer

Added modules:
- Admin dashboard UI
- User management
- Credit adjustments
- Order/payment status view
- Revenue analytics hooks
- Coupon model and validation helpers
- Audit-log model
- Role-based admin guard
- Provider-independent payment integration

This is a deployment-ready scaffold. Connect the data layer to PostgreSQL/Redis and the chosen payment provider before production launch.
