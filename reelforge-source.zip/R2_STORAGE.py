"""Cloudflare R2 S3-compatible storage helper."""
import os
import boto3

def r2_client():
    return boto3.client(
        "s3",
        endpoint_url=os.environ["R2_ENDPOINT_URL"],
        aws_access_key_id=os.environ["R2_ACCESS_KEY_ID"],
        aws_secret_access_key=os.environ["R2_SECRET_ACCESS_KEY"],
        region_name="auto",
    )

def upload_file(path, key, content_type=None):
    extra = {"ContentType": content_type} if content_type else {}
    r2_client().upload_file(path, os.environ["R2_BUCKET"], key, ExtraArgs=extra)

def delete_object(key):
    r2_client().delete_object(Bucket=os.environ["R2_BUCKET"], Key=key)
